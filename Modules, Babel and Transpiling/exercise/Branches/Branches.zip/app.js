let Employee = require("./Employee");
let Branch = require("./Branch");

result.Employee = Employee;
result.Branch = Branch;