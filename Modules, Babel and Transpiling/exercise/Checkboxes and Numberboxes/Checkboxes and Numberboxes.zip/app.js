let Checkbox = require('./Checkbox');
let Numberbox = require('./Numberbox');

//let check = new Checkbox("Is Married:","#married");
//let number = new Numberbox("Age:","#age",1,100);
//let checkbox = $('#married');
//let numberbox = $('#age');
//checkbox.on('change',()=>console.log(check.value));
//numberbox.on('change',()=>console.log(number.value));

//Uncomment bellow and comment above to make it work with judge
result.Numberbox = require('./Numberbox');
result.Checkbox = require('./Checkbox');