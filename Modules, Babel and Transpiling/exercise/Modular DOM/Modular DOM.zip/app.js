let BaseElement = require("./BaseElement");
let Article = require("./Article");
let Footer = require("./Footer");
let ImageArticle = require("./ImageArticle");
let TitleBar = require("./TitleBar");
let TableArticle = require("./TableArticle");

result.BaseElement = BaseElement;
result.Article = Article;
result.Footer = Footer;
result.ImageArticle = ImageArticle;
result.TitleBar = TitleBar;
result.TableArticle = TableArticle;