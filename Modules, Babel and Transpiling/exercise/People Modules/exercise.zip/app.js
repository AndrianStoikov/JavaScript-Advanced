import {Employee} from './Employee';
import {Junior} from './Juniour';
import {Manager} from './Manager';
import {Senior} from './Seniour';

result.Employee = Employee;
result.Junior = Junior;
result.Manager = Manager;
result.Senior = Senior;

//let ht  = new Junior("asddas", 13 , 2132131);
//console.log(ht);