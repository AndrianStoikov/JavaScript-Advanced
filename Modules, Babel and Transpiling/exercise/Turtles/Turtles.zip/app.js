let Turtle = require("./Turtle");
let EvkodianTurtle = require("./EvkodianTurtle");
let GalapagosTurtle = require("./GalapagosTurtle");
let NinjaTurtle = require("./NinjaTurtle");
let WaterTurtle = require("./WaterTurtle");

result.Turtle = Turtle;
result.EvkodianTurtle = EvkodianTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.NinjaTurtle = NinjaTurtle;
result.WaterTurtle = WaterTurtle;

//let testWaterTurtle = new WaterTurtle("Michelangelo", 18, "male", "Sewer");
//let testGalapagosTurtle = new GalapagosTurtle("Raphael", 18, "male");
//let testEvkodianTurtle = new EvkodianTurtle("Donatello", 18, "female", 100);
//let testNinjaTurtle = new NinjaTurtle("Leonardo", 18, "male", "Blue", "Yamato");
//
//console.log(testWaterTurtle.toString());
//// Turtle: Michelangelo
//// Aged - 18; Gender - male
//// Currently inhabiting Sewer
//console.log();
//console.log(testGalapagosTurtle.toString());
//// Turtle: Raphael
//// Aged - 18; Gender - male
//// Things, eaten this year:
//console.log();
//console.log(testEvkodianTurtle.toString());
//// Turtle: Donatello
//// Aged - 18; Gender - male
//// Evkodium: 5400
//console.log();
//console.log(testNinjaTurtle.toString());
// Turtle: Leonardo
// Aged - 18; Gender - male
// Leo wears a Blue mask, and is an apprentice with the Yamato.
